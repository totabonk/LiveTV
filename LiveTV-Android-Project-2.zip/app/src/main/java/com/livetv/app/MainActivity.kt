package com.livetv.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Channel(val name: String, val category: String, val url: String)
data class Match(val teams: String, val time: String)

val channels = listOf(
    Channel("أبوظبي الرياضية", "رياضة", "https://www.admn.ae/"),
    Channel("الشرق للأخبار", "أخبار", "https://asharq.com/"),
    Channel("العربية", "أخبار", "https://www.alarabiya.net/"),
    Channel("beIN SPORTS", "رياضة", "https://www.beinsports.com/ar-mena")
)

val matches = listOf(
    Match("مباراة تجريبية 1", "18:00"),
    Match("مباراة تجريبية 2", "20:30"),
    Match("مباراة تجريبية 3", "22:00")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LiveTV() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveTV() {
    var tab by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf("") }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Live TV", fontWeight = FontWeight.Bold) }) },
        bottomBar = {
            NavigationBar {
                listOf("الرئيسية", "مباشر", "المباريات", "القنوات").forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(listOf("⌂", "●", "⚽", "▦")[i]) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("إعلان", fontWeight = FontWeight.Bold)
                        Text("مكان الإعلان — جاهز لربط AdMob.")
                    }
                }
            }

            when (tab) {
                0 -> {
                    item { SectionTitle("القنوات العربية") }
                    items(channels) { ChannelCard(it) }
                    item { SectionTitle("مباريات اليوم") }
                    items(matches) { MatchCard(it) }
                }
                1 -> {
                    item { SectionTitle("مباشر الآن") }
                    item { Text("المصادر المعروضة هي صفحات رسمية فقط.") }
                    items(channels.take(2)) { ChannelCard(it) }
                }
                2 -> {
                    item { SectionTitle("مباريات اليوم") }
                    item { Text("البيانات حالياً تجريبية، ويمكن لاحقاً ربط API مرخص للمباريات.") }
                    items(matches) { MatchCard(it) }
                }
                3 -> {
                    item {
                        OutlinedTextField(
                            value = search,
                            onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("بحث عن قناة") },
                            singleLine = true
                        )
                    }
                    items(channels.filter { it.name.contains(search, true) || it.category.contains(search, true) }) {
                        ChannelCard(it)
                    }
                }
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}

@Composable
fun ChannelCard(c: Channel) {
    val context = LocalContext.current
    Card(Modifier.fillMaxWidth().clickable {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.url)))
    }) {
        Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(c.name, fontWeight = FontWeight.Bold)
                Text(c.category)
            }
            Button(onClick = {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.url)))
            }) { Text("مشاهدة رسمية") }
        }
    }
}

@Composable
fun MatchCard(m: Match) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(m.teams, Modifier.weight(1f), fontWeight = FontWeight.Bold)
            Text(m.time)
        }
    }
}
